import { useEffect, useMemo, useState } from 'react';
import { auth } from '@appdeploy/client';
import { api } from '@appdeploy/client';
import {
  ArrowDownToLine, ArrowLeft, Check, ChevronDown, Cloud, LogOut,
  MonitorSmartphone, Plus, RefreshCw, Server, ShieldCheck, Smartphone, X,
} from 'lucide-react';

type Device = {
  id: string; name: string; androidVersion: string; region: string;
  status: string; createdAt: number;
};

const versions = ['Android 13', 'Android 12', 'Android 11', 'Android 10'];
const regions = ['India', 'Singapore', 'United States', 'Germany'];

function App() {
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [loading, setLoading] = useState(false);
  const [devices, setDevices] = useState<Device[]>([]);
  const [page, setPage] = useState<'home' | 'create' | 'device'>('home');
  const [selected, setSelected] = useState<Device | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('My Android');
  const [version, setVersion] = useState('Android 13');
  const [region, setRegion] = useState('India');
  const [notice, setNotice] = useState('');
  const [errorText, setErrorText] = useState('');

  useEffect(() => {
    auth.getUser().then(current => {
      setUser(current);
      setAuthLoading(false);
      if (current) loadDevices();
    }).catch(() => {
      setAuthLoading(false);
      setErrorText('Could not restore your session. Please try signing in again.');
    });
  }, []);

  async function loadDevices() {
    setLoading(true);
    try {
      const response = await api.get('/api/devices');
      setDevices(response.data.devices || []);
    } catch {
      setErrorText('Could not load your devices. Refresh and try again.');
    } finally { setLoading(false); }
  }

  async function signIn() {
    setErrorText('');
    try { await auth.signInWithRedirect(); }
    catch (err: any) { setErrorText(err?.message || 'Sign-in could not start. Please retry.'); }
  }

  async function createDevice(event: React.FormEvent) {
    event.preventDefault();
    setErrorText('');
    if (!name.trim()) { setErrorText('Enter a device name.'); return; }
    setLoading(true);
    try {
      const response = await api.post('/api/devices', {
        name: name.trim(), androidVersion: version, region,
      });
      setDevices(current => [response.data.device, ...current]);
      setShowCreate(false); setPage('home');
      setNotice('Device request saved. Connect an Android VM provider to start a real cloud phone.');
    } catch (err: any) {
      setErrorText(err?.response?.data?.error || err?.message || 'Could not save device request.');
    } finally { setLoading(false); }
  }

  async function deleteDevice(device: Device) {
    if (!window.confirm('Delete this device record?')) return;
    try {
      await api.delete('/api/devices/' + encodeURIComponent(device.id));
      setDevices(current => current.filter(item => item.id !== device.id));
      if (selected?.id === device.id) setSelected(null);
      setNotice('Device record deleted.');
    } catch { setErrorText('Could not delete this device record.'); }
  }

  async function signOut() {
    await auth.signOut(); setUser(null); setDevices([]); setPage('home');
  }

  const initials = useMemo(
    () => (user?.name || user?.email || 'N').slice(0, 1).toUpperCase(), [user]
  );

  if (authLoading) return <div className="screen-center"><div className="loader" /><span>Preparing your cloud workspace…</span></div>;

  if (!user) return (
    <main className="login-shell">
      <div className="login-glow" />
      <div className="login-card">
        <div className="brand-mark"><Cloud size={27} /></div>
        <div className="eyebrow">PERSONAL ANDROID CLOUD</div>
        <h1>NOVA <span>CLOUD</span></h1>
        <p className="login-copy">Your cloud device workspace. Manage Android device requests from one clean dashboard.</p>
        <button className="primary-btn full" onClick={signIn}>Continue to sign in <ArrowDownToLine size={17} /></button>
        <div className="login-foot"><ShieldCheck size={14} /> Secure account access</div>
        {errorText && <p className="error-text">{errorText}</p>}
      </div>
      <div className="login-bottom">NOVA CLOUD PHONE <span>•</span> CLOUD DEVICE CONTROL</div>
    </main>
  );

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-row"><div className="brand-mark small"><Cloud size={20} /></div><div><b>NOVA</b><span>CLOUD PHONE</span></div></div>
        <div className="side-label">WORKSPACE</div>
        <button className={page === 'home' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('home'); setSelected(null); }}><MonitorSmartphone size={18} /> My Devices</button>
        <button className="nav-item" onClick={() => setShowCreate(true)}><Plus size={18} /> Create Device</button>
        <div className="side-label second">SYSTEM</div>
        <div className="engine-card"><span className="status-dot" /><div><b>Android engine</b><small>Not connected</small></div></div>
        <div className="sidebar-bottom"><div className="avatar">{initials}</div><div className="user-meta"><b>{user.name || 'NOVA User'}</b><small>{user.email || 'Signed in'}</small></div><button className="icon-btn" title="Sign out" onClick={signOut}><LogOut size={17} /></button></div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="crumb">Workspace <span>/</span> {page === 'device' ? 'Device details' : page === 'create' ? 'Create device' : 'My devices'}</div>
          <div className="top-actions"><span className="engine-pill"><i /> Engine offline</span><button className="icon-btn" title="Refresh devices" onClick={loadDevices}><RefreshCw size={17} /></button></div>
        </header>
        <div className="content">
          {errorText && <div className="alert error-alert"><X size={16} />{errorText}<button onClick={() => setErrorText('')}><X size={15} /></button></div>}
          {notice && <div className="alert success-alert"><Check size={16} />{notice}<button onClick={() => setNotice('')}><X size={15} /></button></div>}
          {page === 'home' && !selected && <>
            <div className="page-heading"><div><div className="eyebrow">YOUR CLOUD WORKSPACE</div><h2>My Devices</h2><p>Manage your Android cloud device requests.</p></div><button className="primary-btn" onClick={() => setShowCreate(true)}><Plus size={18} /> New Device</button></div>
            <section className="hero-card"><div className="hero-orb"><Smartphone size={43} /></div><div className="hero-copy"><div className="hero-tag"><span /> CLOUD CONTROL CENTER</div><h3>Your Android, ready for the cloud.</h3><p>Create and organize device profiles. A cloud Android provider must be connected before live Android sessions can start.</p></div><div className="hero-art"><div className="phone-outline"><div className="phone-camera" /><div className="phone-screen"><Cloud size={30} /><span>ANDROID CLOUD</span><i /></div></div></div></section>
            <div className="section-title"><div><h3>Device overview</h3><p>Your saved device profiles</p></div><span className="count-chip">{devices.length} devices</span></div>
            {loading ? <div className="empty-state"><div className="loader" />Loading devices…</div> : devices.length === 0 ? <div className="empty-state"><div className="empty-icon"><Smartphone size={27} /></div><h3>No devices yet</h3><p>Create your first Android device profile to get started.</p><button className="secondary-btn" onClick={() => setShowCreate(true)}><Plus size={16} /> Create first device</button></div> : <div className="device-grid">{devices.map(device => <article className="device-card" key={device.id}><div className="device-card-top"><div className="device-icon"><Smartphone size={22} /></div><span className="status-badge pending">Awaiting engine</span></div><h4>{device.name}</h4><p>{device.androidVersion} <span>•</span> {device.region}</p><div className="device-card-foot"><span><Server size={14} /> Not provisioned</span><button className="text-btn" onClick={() => { setSelected(device); setPage('device'); }}>Details <ArrowLeft className="arrow-right" size={14} /></button></div></article>)}</div>}
            <div className="notice-panel"><ShieldCheck size={18} /><div><b>Real Android status</b><p>This deployment currently stores device profiles only. Live Android requires an external VM host, Android image, and streaming gateway.</p></div></div>
          </>}
          {page === 'device' && selected && <>
            <button className="back-btn" onClick={() => { setPage('home'); setSelected(null); }}><ArrowLeft size={16} /> Back to devices</button>
            <div className="page-heading"><div><div className="eyebrow">DEVICE PROFILE</div><h2>{selected.name}</h2><p>{selected.androidVersion} · {selected.region}</p></div><button className="danger-btn" onClick={() => deleteDevice(selected)}>Delete record</button></div>
            <div className="stream-panel"><div className="stream-phone"><Smartphone size={54} /><b>Android engine offline</b><span>This profile is saved, but no live Android VM is connected.</span></div><div className="stream-info"><div className="status-badge pending">Not provisioned</div><h3>Live session unavailable</h3><p>Connect a cloud Android VM provider and WebRTC streaming gateway to enable remote touch, keyboard, APK installation and persistent app data.</p><div className="spec-row"><span>Device profile</span><b>{selected.name}</b></div><div className="spec-row"><span>Android version</span><b>{selected.androidVersion}</b></div><div className="spec-row"><span>Region</span><b>{selected.region}</b></div><div className="spec-row"><span>Provisioning</span><b>Waiting for provider</b></div></div></div>
          </>}
          {page === 'create' && <div />}
        </div>
      </main>
      {showCreate && <div className="modal-backdrop" onClick={() => setShowCreate(false)}><form className="create-modal" onSubmit={createDevice} onClick={event => event.stopPropagation()}>
        <div className="modal-head"><div><div className="eyebrow">NEW CLOUD PROFILE</div><h2>Create device</h2></div><button type="button" className="icon-btn" onClick={() => setShowCreate(false)}><X size={19} /></button></div>
        <label>Device name<input value={name} onChange={event => setName(event.target.value)} maxLength={40} placeholder="My Android" /></label>
        <label>Android version<div className="select-wrap"><select value={version} onChange={event => setVersion(event.target.value)}>{versions.map(item => <option key={item}>{item}</option>)}</select><ChevronDown size={16} /></div></label>
        <label>Server region<div className="select-wrap"><select value={region} onChange={event => setRegion(event.target.value)}>{regions.map(item => <option key={item}>{item}</option>)}</select><ChevronDown size={16} /></div></label>
        <div className="capacity-note"><Server size={16} /><span>Device profiles can be saved now. VM creation activates after a provider is connected.</span></div>
        <button className="primary-btn full" disabled={loading}>{loading ? 'Saving profile…' : 'Create device'} <Plus size={17} /></button>
      </form></div>}
    </div>
  );
}
export default App;
