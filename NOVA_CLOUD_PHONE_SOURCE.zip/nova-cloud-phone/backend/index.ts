import { router, json, error, requireAuth } from '@appdeploy/sdk';
import { db } from '@appdeploy/sdk';

function tableFor(userId: string) {
  const safe = userId.replace(/[^A-Za-z0-9]/g, '');
  return 'devices_' + safe;
}

export const handler = router({
  'GET /api/devices': [requireAuth(), async ctx => {
    const result = await db.list(tableFor(ctx.user!.userId), { limit: 100 });
    return json({ devices: result.items });
  }],
  'POST /api/devices': [requireAuth(), async ctx => {
    const body = (ctx.body || {}) as Record<string, unknown>;
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    const androidVersion = typeof body.androidVersion === 'string' ? body.androidVersion : '';
    const region = typeof body.region === 'string' ? body.region : '';
    const allowedVersions = ['Android 13', 'Android 12', 'Android 11', 'Android 10'];
    const allowedRegions = ['India', 'Singapore', 'United States', 'Germany'];
    if (!name || name.length > 40) return error('Device name must be between 1 and 40 characters.', 400);
    if (!allowedVersions.includes(androidVersion)) return error('Choose a supported Android version.', 400);
    if (!allowedRegions.includes(region)) return error('Choose a supported server region.', 400);
    const record = { name, androidVersion, region, status: 'awaiting_engine', createdAt: Date.now(), ownerId: ctx.user!.userId };
    const [id] = await db.add(tableFor(ctx.user!.userId), [record]);
    if (!id) return error('Could not save the device profile. Please retry.', 500);
    return json({ device: { id, ...record } }, 201);
  }],
  'DELETE /api/devices/:id': [requireAuth(), async ctx => {
    const id = ctx.params.id;
    if (!/^[A-Za-z0-9_-]{1,128}$/.test(id)) return error('Invalid device ID.', 400);
    const [deleted] = await db.delete(tableFor(ctx.user!.userId), [id]);
    if (!deleted) return error('Device was not found.', 404);
    return json({ deleted: true });
  }],
  'GET /api/engine/status': [requireAuth(), async () => json({
    connected: false, provider: null,
    message: 'No Android VM provider is configured. Live provisioning and WebRTC streaming are not active.',
  })],
});
