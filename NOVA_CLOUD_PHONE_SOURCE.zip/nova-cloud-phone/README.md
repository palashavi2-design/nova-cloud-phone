# NOVA CLOUD PHONE

This ZIP contains the source snapshot of the AppDeploy project.

## Included
- React + Vite frontend
- Authenticated device-profile API
- Realtime subscription helper files
- AppDeploy sign-in configuration
- Build configuration and basic test descriptions

## Important platform note
The frontend imports `@appdeploy/client` and the backend imports `@appdeploy/sdk`. These are AppDeploy platform integrations and are not included as ordinary npm packages in this export. This project is intended to be restored/deployed in its AppDeploy environment.

## Current functionality
Users can sign in, create Android device profiles, select an Android version and region, view and delete saved profiles.

## Not implemented
This source does **not** provision a real Android virtual machine or provide live Android streaming. A real VM host/provider, Android image, provisioning API and streaming gateway (for example WebRTC) must be configured separately. The app intentionally reports the Android engine as offline until that infrastructure exists.

## GitHub
GitHub stores this source code; it does not itself run the Android cloud phone.
